import './models.css';

function ETS (){
    return(
        <>
            <div className="ETS-body">
                <h2>ETS</h2>
                <img src='./ets.png' />
            </div>
        </>
    );
}

export default ETS;