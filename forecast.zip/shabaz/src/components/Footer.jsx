import React, { useState } from "react";
import './Footer.css'

function Footer() {
    return (
        <>
            <footer>
                <p>Made by <span> Shahbaz Haider </span> &copy; .</p>
            </footer>
        </>
    );
}

export default Footer