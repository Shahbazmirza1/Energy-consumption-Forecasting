import './models.css';

function Arima (){
    return(
        <>
            <div className="Arima-body">
                <h2>ARIMA</h2>
                <img src='./arima.png' />
            </div>
        </>
    );
}

export default Arima;