import './models.css';

function Prophet (){
    return(
        <>
            <div className="Prophet-body">
                <h2>PROPHET</h2>
                <img src='./prophet.png' />
            </div>
        </>
    );
}

export default Prophet;