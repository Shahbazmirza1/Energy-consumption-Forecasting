import './models.css';

function Ann (){
    return(
        <>
            <div className="Ann-body">
                <h2>ANN</h2>
                <img src='./ann.png' />
            </div>
        </>
    );
}

export default Ann;